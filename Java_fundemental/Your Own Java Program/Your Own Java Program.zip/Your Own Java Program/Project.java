public class Project {
	public static void main(String[] args) {
        System.out.println("my name is shadid");
        System.out.println("I am 26 years!");
        System.out.println("My hometown is tullkarm , palestine");
	}
}
